# Use the 'get started'-script from exercise 2 as a basis

# Hint: if you need to find the inverse of a transform T
# consisting of a rotation R and translation t
# then recall that R_inv = transpose(R)
# and t_inv = -R_inv*t

# This can be done easily using numpy - for example
R_inv = np.transpose(R)
t_inv = -np.dot(R_inv,t)
